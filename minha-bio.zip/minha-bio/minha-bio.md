# Bio Daiane Lopes
## Infancia
Nascida em 09/06/1993 em Osasco no hospital das Damas **sim por que sou uma dama**
~~Nasci bem brava sendo minha mae~~
---
Hoje com 29 anos estou aprendendo uma serie de coisas novas como 
um curso de programação <!--Ainda não sei se estou indo bem só que estou me esforçando muito>

```console.log("Olá!")```

 
